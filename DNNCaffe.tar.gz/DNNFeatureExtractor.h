#ifndef __DNNFEATUREEXTRACTOR_H__
#define __DNNFEATUREEXTRACTOR_H__

#define USE_OPENCV

#include <caffe/caffe.hpp>
#ifdef USE_OPENCV
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#endif  // USE_OPENCV
#include <algorithm>
#include <iosfwd>
#include <memory>
#include <string>
#include <utility>
#include <vector>

using namespace caffe;  // NOLINT(build/namespaces)
using std::string;

/* Pair (label, confidence) representing a prediction. */
//typedef std::pair<int, float> Prediction;

/* Pair (label, confidence) representing a prediction. */
typedef std::pair<string, float> Prediction;

class DNNFeatureExtractor {
 public:
/*
  DNNFeatureExtractor(const string& model_file,
             const string& trained_file,
             const string& mean_file);
*/
  DNNFeatureExtractor(const string& model_file,
             const string& trained_file,
             const string& mean_file,
             const string& label_file);

//  std::vector<Prediction> Classify(const cv::Mat& img);
  std::vector<Prediction> Classify(const cv::Mat& img, int N);
  std::vector<float> GetFeature(const cv::Mat& img);

 private:
  void SetMean(const string& mean_file);
  std::vector<float> Predict(const cv::Mat& img);

  void WrapInputLayer(std::vector<cv::Mat>* input_channels);

  void Preprocess(const cv::Mat& img,
                  std::vector<cv::Mat>* input_channels);

 private:
  shared_ptr<Net<float> > net_;
  cv::Size input_geometry_;
  int num_channels_;
  cv::Mat mean_;
  std::vector<string> labels_;
};


#endif
