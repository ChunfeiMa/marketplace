#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv/highgui.h>
#include "opencv2/highgui/highgui.hpp"
//#include "FC.h"

#include <face_detector/FaceDetector.h>
#include <partialface_detector/PartialFaceDetector.h>
#include <headpose_estimator/HeadPoseEstimator.h>

#include <feature_extractor/FeatureExtractor.h>
#include <feature_extractor/FeatureExtractorDef.h>
#include <feature_extractor/DNNFeatureExtractor.h>


#include <vector>

#define CAMERA_MODE
#define MAX_PATH 	512

#include <types/baseType.h>
#include <types/faceType.h>

using namespace std;
using namespace niu;
/***************************************************************************************************
                                        FUNCTION PROTOTYPE
***************************************************************************************************/
int MakeInputImage(NormalizedImage *pNormalizeImage, unsigned char *ucpNorm);
int AgeVoting(const char* cr1, const char* cr2, char* result);
int AgeVoting(const char* cr1, const char* cr2,const char* cr3, char* result);
bool isMajority(bool v1,bool v2,bool v3);
/***************************************************************************************************
                                         FUNCTION DEFINITIONS
***************************************************************************************************/


#if 1
int main()
{
    char	model_file[MAX_PATH];
	char	trained_file[MAX_PATH];
	char	mean_file[MAX_PATH];
	char	label_file[MAX_PATH];

    FaceDetector		    *pFaceDetector;
    PartialFaceDetector 	*pPartialFaceDetector;
    HeadPoseEstimator	    *pHeadPoseEstimator;
    FeatureExtractor	    *pFeatureExtractor;
    DNNFeatureExtractor	    *pDNNAgeRecognizer;
    DNNFeatureExtractor	    *pDNNGenderRecognizer;
    DNNFeatureExtractor	    *pDNNAgeRecognizer_new;
    DNNFeatureExtractor	    *pDNNAgeRecognizer_new2;

    DNNFeatureExtractor     *pDNNExpressionRecognizer;

    FaceDetectResult	    *pFaceDetectResult;
	HeadPose		        *pHeadPose;
	NormalizedImage		    *pNormalizeImage;
//  FaceFeature		        *pFaceFeature;
//	JBFeature		        *pJBFeature;
//	FaceDNNFeature		    *pFaceDNNFeature;


/***************************************************************************************************
                                         OBJECT CONSTRUCTION
***************************************************************************************************/

    /**************************/
    /*****Face Detection*******/
    /**************************/
    pFaceDetector = new FaceDetector();
    pFaceDetector->prepare();
    pFaceDetector->create();
    pFaceDetector->setMaxFaceNum(10);
    pFaceDetector->setMode(FD_IMAGE_MODE);
    pFaceDetector->setFaceSizeRange(80,1024);
    pFaceDetector->setFaceAngleRange(FD_ANGLE_R115);
    pFaceDetector->setOrderingPolicy(FD_SIZE_ORDERED);

    /**************************/
    /***Landmark Detection*****/
    /**************************/
    pPartialFaceDetector = new PartialFaceDetector();
    if(!pPartialFaceDetector->prepare())
    {
        printf("LD Initialization Fail!\n");
        return false;
    }

    /*********************************/
    /*****Head Pose Estimator*********/
    /*********************************/
    pHeadPoseEstimator = new HeadPoseEstimator();

    /**************************/
    /*****Normalization********/
    /**************************/
    pFeatureExtractor = new FeatureExtractor();

    if(!pFeatureExtractor->prepare())
    {
        printf("pFeatureExtractor failed\n");
        return false;
    }

    /************************************/
    /*******Age&GenderRecognizer*********/
    /************************************/

    //AGE
    /*************4 class***********************/
/*
    //Gray_Version
    //00-20-40-60
    sprintf(model_file, "/home/ethanlee/Ma/test/our0/4class/0246/gray/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/our0/4class/0246/gray/_iter_50000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/our0/4class/0246/gray/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/our0/4class/0246/gray/lables.txt");
    pDNNAgeRecognizer_new = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/

/*
    //Gray_Version
    //10-30-50-70
    sprintf(model_file, "/home/ethanlee/Ma/test/our0/4class/1357/gray/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/our0/4class/1357/gray/_iter_50000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/our0/4class/1357/gray/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/our0/4class/1357/gray/lables.txt");
    pDNNAgeRecognizer_new2 = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/

    /*************5 class***********************/
/*
    //Gray_Version
    sprintf(model_file, "/home/ethanlee/Ma/test/our0/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/our0/_iter_50000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/our0/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/our0/lables.txt");
    pDNNAgeRecognizer = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/
/*
    //180x180 gray version
    sprintf(model_file, "/home/ethanlee/Ma/test/our0/180x180/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/our0/180x180/_iter_500000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/our0/180x180/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/our0/180x180/lables.txt");
    pDNNAgeRecognizer = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/
/*
    //Color_Version
    sprintf(model_file, "/home/ethanlee/Ma/test/our0/color/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/our0/color/_iter_40000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/our0/color/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/our0/color/lables.txt");
    pDNNAgeRecognizer = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/
    /*************9 class***********************/
/*
    //Gray_Version
    sprintf(model_file, "/home/ethanlee/Ma/test/our0/9class/gray/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/our0/9class/gray/_iter_50000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/our0/9class/gray/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/our0/9class/gray/lables.txt");
    pDNNAgeRecognizer_new = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/
/*
    //Color_Version
    sprintf(model_file, "/home/ethanlee/Ma/test/our0/9class/color/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/our0/9class/color/_iter_50000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/our0/9class/color/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/our0/9class/color/lables.txt");
    pDNNAgeRecognizer_new = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/
    //GENDER
/*
    //Gray_Version
    sprintf(model_file, "/home/ethanlee/Ma/test/gender/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/gender/_iter_40000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/gender/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/gender/labels_gender.txt");
    pDNNGenderRecognizer= new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
 */
 /*
    //Color_Version
    sprintf(model_file, "/home/ethanlee/Ma/test/gender/color/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/gender/color/_iter_100000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/gender/color/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/gender/color/labels_gender.txt");
    pDNNGenderRecognizer= new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
 */
    /*************16 class***********************/
/*
    //Gray_Version
    //Age&Gender
    sprintf(model_file, "/home/ethanlee/Ma/test/our0/16class/gray/convnet_128_train_test_BIGGER_our0_deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/our0/16class/gray/_iter_50000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/our0/16class/gray/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/our0/16class/gray/lables.txt");
    pDNNAgeRecognizer = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/
    /*************16 class new 2016.08.22***********************/
/**/
    //Gray_Version
    //Age&Gender
    sprintf(model_file, "/home/ethanlee/Ma/test/new_dropout2/convnet_128_train_test_BIGGER_our0_2dropout_deploy_new.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/new_dropout2/_iter_500000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/new_dropout2/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/new_dropout2/lables_1.txt");
    pDNNAgeRecognizer_new = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);

    /*************16 class new 2016.11.16***********************/
/**/
    //Gray_Version
    //Age&Gender
    sprintf(model_file, "/home/ethanlee/Ma/test/Augmented_dropout2/convnet_128_train_test_BIGGER_our0_2dropout_deploy_new.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/Augmented_dropout2/Augmented_2droput_iter_500000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/Augmented_dropout2/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/Augmented_dropout2/lables_age.txt");
    pDNNAgeRecognizer = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);

    /************************************/
    /*******ExpressionRecognizer*********/
    /************************************/

/*
    //Gray_Version 40x40
    //Expression
    sprintf(model_file, "/home/ethanlee/Ma/test/Expression/deploy.prototxt");
	sprintf(trained_file, "/home/ethanlee/Ma/test/Expression/_iter_180000.caffemodel");
	sprintf(mean_file, "/home/ethanlee/Ma/test/Expression/mean.binaryproto");
	sprintf(label_file, "/home/ethanlee/Ma/test/Expression/lables.txt");
    pDNNExpressionRecognizer = new DNNFeatureExtractor(model_file,trained_file,mean_file,label_file);
*/

    /*************************************/
    /*******Intermediated objects*********/
    /*************************************/
    pHeadPose = new HeadPose();
    pNormalizeImage = new NormalizedImage();
//	pFaceFeature = new FaceFeature();
//	pJBFeature = new JBFeature();
//	pFaceDNNFeature = new FaceDNNFeature();


#ifdef CAMERA_MODE
	CvCapture	*capture = cvCaptureFromCAM(0);

	if (!capture){
		printf("Camera connection failed!");
		return 0;
	}
#else
	CvCapture* capture = 0;
	capture = cvCreateFileCapture("BMT이마트성수xvid640x480_160728.avi");
#endif


	int	i_width, i_height;
	i_width = (int)cvGetCaptureProperty(capture, CV_CAP_PROP_FRAME_WIDTH);
	i_height = (int)cvGetCaptureProperty(capture, CV_CAP_PROP_FRAME_HEIGHT);
	int nFrameWidth;
    int nFrameHeight;

	IplImage	    *image = 0;
	IplImage	    *pGray = cvCreateImage(cvSize(i_width, i_height), IPL_DEPTH_8U, 1);
	IplImage	    *pFrame4;

	unsigned char   *pGrayImgData;
    int             nFrameNumber = 0;
    bool            flag = false;
    int             nFaceCount = 0;
    int		        nSharpness;
    IplImage        *pNorm = cvCreateImage(cvSize(FIT_FE_NORM_WIDTH, FIT_FE_NORM_HEIGHT), IPL_DEPTH_8U, 3);
    IplImage        *pNormGray = cvCreateImage(cvSize(FIT_FE_NORM_WIDTH, FIT_FE_NORM_HEIGHT), IPL_DEPTH_8U, 1);
    unsigned char	*ucpBGR;
    ucpBGR = (unsigned char *)malloc(sizeof(unsigned char)*i_width*i_height*3);

    CvFont font;
	cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX, 1.0, 1.0, 0.0, 2, CV_AA);
    CvFont font_;
	cvInitFont(&font_, CV_FONT_HERSHEY_SIMPLEX, 0.5, 0.5, 0.0, 1, CV_AA);
	int  key = 0;
	char cstrr[512];
	bool flag2Vote = FALSE;
	bool flag3Vote = FALSE;

    while (1)
    {
        nFrameNumber++;
        nFrameNumber%=10000;

		printf("[frame %d]\n ", nFrameNumber);

		cvGrabFrame(capture);
		image = cvRetrieveFrame(capture);

		if (image == NULL)
			break;

		cvCvtColor(image, pGray, CV_BGR2GRAY);
		pGrayImgData = (unsigned char *)pGray->imageData;

		/**************************/
		/*****Face Detection*******/
        /**************************/
        pFaceDetector->setResolution(pGray->width,pGray->height);
        pFaceDetectResult = new FaceDetectResult(pFaceDetector->getMaxFaceNum());

        flag = pFaceDetector->faceDetection(pGrayImgData,pFaceDetectResult,0);
        if(!flag)
            printf("FD fails!\n");

        nFaceCount = pFaceDetectResult->faceCount;
        if(nFaceCount == 0)
        {
            printf("Face Detection Failed!\n");
//            cvPutText(image, "Face Detection Failed!", cvPoint(200, 50), &font, cvScalar(0, 0, 255, 0));
            cvShowImage("AgeGenderExpressionLinuxVersionDemo", image);
            cvWaitKey(30);
            continue;
        }
        printf("Frame %5d FaceNum %3d  RollAngle %d\n", nFrameNumber, nFaceCount, pFaceDetectResult->pRollAngle[0]);

        /**************************/
		/***Landmark Detection*****/
        /**************************/
        flag = pPartialFaceDetector->partialFaceDetection(pGrayImgData,pGray->width,pGray->height,pFaceDetectResult);
        if(!flag)
            printf("LD fails!\n");

        for(int faceIndex=0;faceIndex<nFaceCount;faceIndex++)
        {
            //Only the biggest face
            if(faceIndex==1)
                break;
        /**************************/
		/*****Normalization********/
        /**************************/
        nFrameWidth = ((image->width)>>2)<<2;
		nFrameHeight = ((image->height)>>2)<<2;

		pFrame4 = cvCreateImage(cvSize(nFrameWidth,nFrameHeight), IPL_DEPTH_8U,3);
		cvResize(image, pFrame4, 1);

        int nColorWStep = pFrame4->widthStep;
		int gstart = nFrameWidth*nFrameHeight;
		int rstart = nFrameWidth*nFrameHeight*2;
		for (int i = 0; i < nFrameHeight; i++ )
		{
			for (int j = 0; j < nFrameWidth; j++ )
		    {
				ucpBGR[i*nFrameWidth+j] =  (unsigned char)pFrame4->imageData[i*nColorWStep + j*3];
				ucpBGR[gstart+i*nFrameWidth+j] = (unsigned char)pFrame4->imageData[i*nColorWStep + j*3 + 1];
				ucpBGR[rstart+i*nFrameWidth+j] = (unsigned char)pFrame4->imageData[i*nColorWStep + j*3 + 2];
			}
		}

        flag = pFeatureExtractor->normalizeImage(ucpBGR,nFrameWidth,nFrameHeight,pFaceDetectResult,faceIndex,pNormalizeImage);

        if(!flag)
        printf("Normalization failed!\n");

        flag = pFeatureExtractor->getBestFaceScore(pNormalizeImage,&nSharpness);

        //if blur
        // if(nSharpness < 6000) continue;

        /*********************************/
		/*****Head Pose Estimation********/
        /*********************************/
		pHeadPoseEstimator->headPoseEstimation(nFrameWidth, nFrameHeight, &pFaceDetectResult->pFacePartialDetectResult[faceIndex], pHeadPose);
        if(abs(int(pHeadPose->pitch)) > 35 || abs(int(pHeadPose->yaw)) > 35)
        {
            cvPutText(image, "Please face forward!", cvPoint(200, 100), &font, cvScalar(255, 0, 255, 0));
            continue;
        }

        /******************************/
		/*******Age Recognition********/
        /******************************/

        flag = MakeInputImage(pNormalizeImage,(unsigned char*)pNorm->imageData);
        cvCvtColor(pNorm,pNormGray,CV_BGR2GRAY);

        cv::Mat pCropedFaceImg(pNormGray,cv::Rect(0,30,180,180)); //In accordance with training samples
 //       cv::Mat pCropedFaceImg(pNormGray,cv::Rect(0,5,80,80)); //In accordance with training samples
        cv::Mat pFaceImg;

        cv::resize(pCropedFaceImg, pFaceImg, cv::Size(80,80)); //for age

        cv::imshow("CroppedBeforeNormalized", pCropedFaceImg);

        //Age
        std::vector<Prediction> predictionsAge = pDNNAgeRecognizer->Classify(pFaceImg,3);
        std::vector<Prediction> predictionsAge_new = pDNNAgeRecognizer_new->Classify(pFaceImg,3);
//        std::vector<Prediction> predictionsAge_new2 = pDNNAgeRecognizer_new2->Classify(pFaceImg,3);


        for (size_t i = 0; i < predictionsAge.size(); ++i)
        {
            Prediction pAge = predictionsAge[i];
            std::cout << std::fixed << std::setprecision(4) << pAge.second << " - \""
                              << pAge.first << "\"" << std::endl;
        }

        if(predictionsAge[0].second > 0.08)
        {
            const char *cstr = predictionsAge[0].first.c_str();
            cvPutText(image, cstr, cvPoint(20, 190), &font, cvScalar(255, 255, 0, 0));

            sprintf(cstrr, "(%.2f)", predictionsAge[0].second);
            cvPutText(image, cstrr, cvPoint(260, 185), &font_, cvScalar(255, 255, 0, 0));
        }

        if(predictionsAge_new[0].second > 0.08)
        {
            const char *cstr1 = predictionsAge_new[0].first.c_str();
            cvPutText(image, cstr1, cvPoint(20, 190+30), &font, cvScalar(255, 0, 255, 0));

            sprintf(cstrr, "(%.2f)", predictionsAge_new[0].second);
            cvPutText(image, cstrr, cvPoint(260, 185+30), &font_, cvScalar(255, 0, 255, 0));
        }
/*
        if(predictionsAge_new2[0].second > 0.08)
        {
            const char *cstr2 = predictionsAge_new2[0].first.c_str();
            cvPutText(image, cstr2, cvPoint(20, 190+30+30), &font, cvScalar(255, 255, 0, 0));

            sprintf(cstrr, "(%.2f)", predictionsAge_new2[0].second);
            cvPutText(image, cstrr, cvPoint(160, 185+30+30), &font_, cvScalar(255, 255, 0, 0));
        }
*/
#if 0
        /************Voting Age*********************/
        char cstr_final[512];

        if(flag2Vote)
        {
            AgeVoting(predictionsAge[0].first.c_str(),predictionsAge_new[0].first.c_str(),cstr_final);
            strcat (cstr_final,"-2vote");
            cvPutText(image, cstr_final, cvPoint(20, 190+30+30+30), &font, cvScalar(185, 100, 255, 0));
        }
        else if(flag3Vote)
        {
            AgeVoting(predictionsAge[0].first.c_str(),predictionsAge_new[0].first.c_str(),predictionsAge_new2[0].first.c_str(),cstr_final);
            strcat (cstr_final,"-3vote");
            cvPutText(image, cstr_final, cvPoint(20, 190+30+30+30), &font, cvScalar(255, 0, 185, 0));
        }
        else
            cvPutText(image, predictionsAge[0].first.c_str(), cvPoint(20, 190+30+30+30), &font, cvScalar(255, 0, 255, 0));

#endif


        /*********************************/
		/*******Gender Recognition********/
        /*********************************/
#if 0
 //       cv::resize(pCropedFaceImg, pFaceImg, cv::Size(80,80)); //for gender
        //Gender
        std::vector<Prediction> predictionsGender = pDNNGenderRecognizer->Classify(pFaceImg,3);

        for (size_t i = 0; i < predictionsGender.size(); ++i)
        {
            Prediction pGender = predictionsGender[i];
            std::cout << std::fixed << std::setprecision(4) << pGender.second << " - \""
                        << pGender.first << "\"" << std::endl;
        }

        if(predictionsGender[0].second > 0.9)
        {
            const char *cstr01 = predictionsGender[0].first.c_str();
            if(strcmp (cstr01,"FEMALE") == 0)
                cvPutText(image, cstr01, cvPoint(20, 160), &font, cvScalar(0, 0, 255, 0));
            else
                cvPutText(image, cstr01, cvPoint(20, 160), &font, cvScalar(255, 255, 0, 0));

            sprintf(cstrr, "(%.2f)", predictionsGender[0].second);
            if(strcmp (cstr01,"FEMALE") == 0)
                cvPutText(image, cstrr, cvPoint(160, 160), &font_, cvScalar(0, 0, 255, 0));
            else
                cvPutText(image, cstrr, cvPoint(160, 160), &font_, cvScalar(255, 255, 0, 0));
        }

#endif // 0


        /*********************************/
		/*******Expression Recognition********/
        /*********************************/
#if 0
        cv::resize(pCropedFaceImg, pFaceImg, cv::Size(40,40)); //for gender
        //Expression
        std::vector<Prediction> predictionsExpression = pDNNExpressionRecognizer->Classify(pFaceImg,3);

        for (size_t i = 0; i < predictionsExpression.size(); ++i)
        {
            Prediction pExpression = predictionsExpression[i];
            std::cout << std::fixed << std::setprecision(4) << pExpression.second << " - \""
                        << pExpression.first << "\"" << std::endl;
        }

        if(predictionsExpression[0].second > 0.0)
        {
            const char *cstr0 = predictionsExpression[0].first.c_str();
            cvPutText(image, cstr0, cvPoint(20, 360), &font, cvScalar(0, 0, 255, 0));

            sprintf(cstrr, "(%.2f)", predictionsExpression[0].second);
            cvPutText(image, cstrr, cvPoint(160, 360), &font_, cvScalar(0, 0, 255, 0));
        }

#endif // 0





        cvRectangle(image,cvPoint(pFaceDetectResult->pFaceRect[faceIndex].leftTop.x,pFaceDetectResult->pFaceRect[faceIndex].leftTop.y),cvPoint(pFaceDetectResult->pFaceRect[faceIndex].rightBottom.x, pFaceDetectResult->pFaceRect[faceIndex].rightBottom.y),CV_RGB(255,255,0),2);

        } //for(int faceIndex=0;faceIndex<nFaceCount;faceIndex++)


        cvShowImage("AgeGenderExpressionLinuxVersionDemo", image);
        key = cvWaitKey(30);

        if(key == 'q')
            break;
        else if(key == 's')
            cvWaitKey(0);
        else if(key == 'o')
        {
            flag2Vote = TRUE;
            flag3Vote = FALSE;
        }
        else if(key== 'p')
        {
            flag3Vote = TRUE;
            flag2Vote = FALSE;
        }
        else if(key== 'i')
        {
            flag3Vote = FALSE;
            flag2Vote = FALSE;
        }
    } //while (1)

    delete pFaceDetectResult;
    delete pNormalizeImage;
    delete pHeadPose;
//  delete pFaceDNNFeature;
//  delete pFaceFeature;
//	delete pJBFeature;
    cvReleaseImage(&pNorm);
    cvReleaseImage(&pNormGray);
    cvReleaseImage(&pFrame4);
    free(ucpBGR);

    pFaceDetector->release();
	pPartialFaceDetector->release();
	pFeatureExtractor->release();


    if(pFaceDetector)
        delete pFaceDetector;
    if(pPartialFaceDetector)
        delete pPartialFaceDetector;
    if(pHeadPoseEstimator)
        delete pHeadPoseEstimator;
    if(pFeatureExtractor)
        delete pFeatureExtractor;
    if(pDNNAgeRecognizer)
        delete pDNNAgeRecognizer;
    if(pDNNGenderRecognizer)
        delete pDNNGenderRecognizer;
    if(pDNNAgeRecognizer_new)
        delete pDNNAgeRecognizer_new;

    printf("Memory release is done! \n");

}
#endif // 0


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int MakeInputImage(NormalizedImage *pNormalizeImage, unsigned char *ucpNorm)
{
    int gstart;
    int rstart;
    int wStep;
    int targetIdx;

		gstart = FIT_FE_NORM_WIDTH*FIT_FE_NORM_HEIGHT;
		rstart = FIT_FE_NORM_WIDTH*FIT_FE_NORM_HEIGHT*2;
        wStep = FIT_FE_NORM_WIDTH*3;

		for (int k = 0; k < FIT_FE_NORM_HEIGHT; k++ )
		{
			for (int j = 0; j < FIT_FE_NORM_WIDTH; j++ )
		    {
				targetIdx = k*wStep + j*3;
				ucpNorm[targetIdx] = pNormalizeImage->image[k*FIT_FE_NORM_WIDTH+j];
				ucpNorm[targetIdx + 1] = pNormalizeImage->image[gstart+k*FIT_FE_NORM_WIDTH+j];
				ucpNorm[targetIdx + 2] = pNormalizeImage->image[rstart+k*FIT_FE_NORM_WIDTH+j];
			}
		}

    return 1;
}
int AgeVoting(const char* cr1, const char* cr2, char* result)
{
    if(strcmp (cr1,"Age05") == 0 && (strcmp (cr2,"Age00") == 0 || strcmp (cr2,"Age05") == 0))
        strcpy(result,"Age05");
    else if(strcmp (cr1,"Age10") == 0 && strcmp (cr2,"Age10") == 0)
        strcpy(result,"Age10");
    else if(strcmp (cr1,"Age2030") == 0 && (strcmp (cr2,"Age20") == 0 || strcmp (cr2,"Age30") == 0))
        strcpy(result,"Age2030");
    else if(strcmp (cr1,"Age4050") == 0 && (strcmp (cr2,"Age40") == 0 || strcmp (cr2,"Age50") == 0))
        strcpy(result,"Age4050");
    else if(strcmp (cr1,"Age6070") == 0 && (strcmp (cr2,"Age60") == 0 || strcmp (cr2,"Age70") == 0))
        strcpy(result,"Age6070");
    else
        strcpy(result,cr1);

    return 1;
}
int AgeVoting(const char* cr1, const char* cr2,const char* cr3, char* result)
{
/*
    if(strcmp (cr1,"Age05") == 0 && (strcmp (cr2,"Age00") == 0 || strcmp (cr2,"Age05") == 0))
        strcpy(result,"Age05");
    else if(strcmp (cr1,"Age10") == 0 && (strcmp (cr2,"Age10") == 0 || strcmp (cr3,"Age10") == 0))
        strcpy(result,"Age10");
    else if(strcmp (cr1,"Age2030") == 0 && ((strcmp (cr2,"Age20") == 0 || strcmp (cr2,"Age30") == 0) || strcmp (cr3,"Age30") == 0))
        strcpy(result,"Age2030");
    else if(strcmp (cr1,"Age4050") == 0 && ((strcmp (cr2,"Age40") == 0 || strcmp (cr2,"Age50") == 0) || strcmp (cr3,"Age50") == 0))
        strcpy(result,"Age4050");
    else if(strcmp (cr1,"Age6070") == 0 && ((strcmp (cr2,"Age60") == 0 || strcmp (cr2,"Age70") == 0) || strcmp (cr3,"Age70") == 0))
        strcpy(result,"Age6070");
    else
        strcpy(result,"Unsure");
*/
/**/
    //1357 model
    bool flg05_1,flg05_2,flg05_3;
    bool flg10_1,flg10_2,flg10_3;
    bool flg2030_1,flg2030_2,flg2030_3;
    bool flg4050_1,flg4050_2,flg4050_3;
    bool flg6070_1,flg6070_2,flg6070_3;

    flg05_1 = (strcmp (cr1,"Age05") == 0);
    flg05_2 = (strcmp (cr2,"Age00") == 0 || strcmp (cr2,"Age05") == 0);
    flg05_3 = (strcmp (cr3,"Age00") == 0);

    flg10_1 = (strcmp (cr1,"Age10") == 0);
    flg10_2 = (strcmp (cr2,"Age10") == 0);
    flg10_3 = (strcmp (cr3,"Age10") == 0);

    flg2030_1 = (strcmp (cr1,"Age2030") == 0);
    flg2030_2 = (strcmp (cr2,"Age20") == 0 || strcmp (cr2,"Age30") == 0);
    flg2030_3 = (strcmp (cr3,"Age30") == 0);

    flg4050_1 = (strcmp (cr1,"Age4050") == 0);
    flg4050_2 = (strcmp (cr2,"Age40") == 0 || strcmp (cr2,"Age50") == 0);
    flg4050_3 = (strcmp (cr3,"Age50") == 0);

    flg6070_1 = (strcmp (cr1,"Age6070") == 0);
    flg6070_2 = (strcmp (cr2,"Age60") == 0 || strcmp (cr2,"Age70") == 0);
    flg6070_3 = (strcmp (cr3,"Age70") == 0);


    int count = 0;
    if(isMajority(flg05_1,flg05_2,flg05_3))
    {
        strcpy(result,"Age05");
    }
    else if (isMajority(flg10_1,flg10_2,flg10_3))
    {
        strcpy(result,"Age10");
    }
    else if (isMajority(flg2030_1,flg2030_2,flg2030_3))
    {
        strcpy(result,"Age2030");
    }
    else if (isMajority(flg4050_1,flg4050_2,flg4050_3))
    {
        strcpy(result,"Age4050");
    }
    else if (isMajority(flg6070_1,flg6070_2,flg6070_3))
    {
        strcpy(result,"Age6070");
    }
    else
    {
        strcpy(result,"Unsure");
    }

    return 1;
}
bool isMajority(bool v1,bool v2,bool v3)
{
    if((v1&&v2) || (v1&&v3) || (v2&&v3))
        return TRUE;
    else
        return FALSE;
}
