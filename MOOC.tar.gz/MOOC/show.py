import numpy as np
from PIL import Image
import os
import time


list = os.listdir("/media/ethanlee/Home2/MC/landmark")

for i in range(len(list)):
	img = np.loadtxt(list[i])
	IMG = Image.fromarray(img)
	IMG.show()
	time.sleep(1.5)

