
def counting(array,x,y):
    res = 0
    L = []
    LL = []
    n = len(array)

    for i in range(len(array)):
        L.append(array[i])
        for j in range(len(array)-1):
            for k in range(n):
                LL.append(array[k])
            L.append(LL)
            LL = []
        array.pop(0)

    return  res

def input():
    n,q = raw_input("input two integer!: ").split()
    n,q = int(n),int(q)

    array = raw_input("input the array, like: ").split()
    for i in range(q):
        x, y = str(raw_input("input the x , y: ")).split()
        x,y = int(x), int(y)
        res = counting(array,x,y)
        print("count is : %d\n"%(res))

if __name__ == "__main__":
    print(input())