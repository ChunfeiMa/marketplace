from collections import defaultdict

class GraduationPro:
    def __init__(self):
        self.semesterCount = 0
        self.maskOfFinishedCourse = 0
        self.maskOfFinishedCourse_temp = 0
        # self.maskOfPrerequisite = defaultdict(list)
        # self.maskOfOpenedCourse = defaultdict(list)


    def makeMask(self,num):
        '''
        receive input then convert the index into bit-mask
        :param num:
        :param mask:
        :return:
        '''
        # mask = defaultdict(list)
        mask = []

        for n in range(num):
            indexOfPrere = map(int,raw_input().strip().split())
            # remove the first number since it is unnecessary
            indexOfPrere.pop(0)
            tt = 0
            for t in indexOfPrere:
                tt |= (1 << t)
            # mask[n].append(tt)
            mask.append(tt)
        return mask

    def _input_(self,Num_test):
        N,K,M,L = map(int,raw_input().strip().split())
        self.N_totalCourse,self.K_courseNeed2Listen,self.M_semester,self.L_maxNumOfSemes = N,K,M,L

        # set N masks to indicate prerequisite course for N courses
        # eg.,
        # 0 -> [0 0 0 0]
        # 1 -> [0 0 0 1]
        # 2 -> [1 0 1 1]
        # 3 -> [0 0 0 0]
        self.maskOfPrerequisite = self.makeMask(N)

        # set M masks to indicate opened course for M semesters
        # eg.,
        # 1 -> [1 1 1 1]
        # 2 -> [1 1 1 1]
        # 3 -> [1 0 1 1]
        # 4 -> [1 1 1 1]
        self.maskOfOpenedCourse = self.makeMask(M)

    def count(self,Num_test):
        for _ in range(Num_test):
            self._input_(Num_test)
            self.__init__()
            for semester in range(self.M_semester):
                self.semesterCount += 1
                # Set the intermediate mask in order to avoid the dependent error
                # (i.e., 0 th course leads to 1 th course available immediately in the same semester)
                self.maskOfFinishedCourse_temp = self.maskOfFinishedCourse
                for course in range(self.N_totalCourse):

                    # If all the courses has been finished(listened)
                    if bin(self.maskOfFinishedCourse_temp).count("1") == self.K_courseNeed2Listen:
                        result =  self.semesterCount
                        break

                    # If this course has been listened already, just pass it
                    if self.maskOfFinishedCourse & (1 << course) == 1:
                        continue

                    # temp = ~(self.maskOfOpenedCourse[semester] & (1 << course)) & self.maskOfPrerequisite[course]

                    temp = self.maskOfOpenedCourse[semester] & (1 << course)
                    # if this course isn't opened in this semester
                    if temp == 0:
                        continue

                    # if opened obtain its prerequisite coures
                    temp = (~temp) & self.maskOfPrerequisite[course]

                    # If no prerequisite course
                    if temp == 0:
                        self.maskOfFinishedCourse_temp |= (1 << course)
                    # If prerequisite exists check if this course has been listened
                    else:
                        # for cur in range(self.N_totalCourse):
                        #     c = temp & (1 << cur)
                        #     if c!=0 and (c & self.maskOfFinishedCourse)!=0:
                        #         self.maskOfFinishedCourse_temp |= (1 << course)
                        if temp & self.maskOfFinishedCourse == temp:
                             self.maskOfFinishedCourse_temp |= (1 << course)

                # If nothing can be listened in this semester, count semester down by 1
                if bin(self.maskOfFinishedCourse).count("1") == bin(self.maskOfFinishedCourse_temp).count("1"):
                    self.semesterCount -= 1
                self.maskOfFinishedCourse = self.maskOfFinishedCourse_temp

            if bin(self.maskOfFinishedCourse).count("1") < self.K_courseNeed2Listen:
                        result = "IMPOSSIBLE"
            print(result)

def main():
    num_test = input()
    GraduationPro().count(num_test)


if __name__ == '__main__':
    main()

    # def _input_(self,Num_test):
    #     for _ in Num_test:
    #         N,K,M,L = map(int,raw_input().strip().split())
    #
    #         # set N masks to indicate prerequisite course for N courses
    #         # eg.,
    #         # 0 -> [0 0 0 0]
    #         # 1 -> [0 0 0 0]
    #         # 2 -> [1 0 1 1]
    #         # 3 -> [0 0 0 1]
    #
    #         for n in N:
    #             indexOfPrere = map(int,raw_input().strip().split())
    #             # remove the first number since it is unnecessary
    #             indexOfPrere.pop(0)
    #             tt = 0
    #             for t in indexOfPrere:
    #                 tt &= (1 << (t+1))
    #             self.maskOfPrerequisite[n].append(tt)
    #
    #         # set M masks to indicate opened course for M semesters
    #         # eg.,
    #         # 1 -> [1 1 1 1]
    #         # 2 -> [1 1 1 1]
    #         # 3 -> [1 1 0 1]
    #         # 4 -> [1 1 1 1]
    #
    #         for m in M:
    #             indexOfOpenedCourse = map(int,raw_input().strip().split())
    #             # remove the first number since it is unnecessary
    #             indexOfOpenedCourse.pop(0)
    #             tt = 0
    #             for t in indexOfOpenedCourse:
    #                 tt &= (1 << (t+1))
    #             self.maskOfOpenedCourse[m].append(tt)
