# chunfei.ma@lge.com
from __future__ import print_function

num_sheep_l = [1,4,5,9,10]
num_stick_l = [1,3,2,3,2]
sheep_stick_dict = {'1':1,
                    '4':3,
                    '5':2,
                    '9':3,
                    '10':2}
res = False
#recursive function to solve the Roman shepherds problem
# def Roman_shepherds(n,k):
#     global res
#
#     if n in num_sheep_l:
#         res = (sheep_stick_dict[str(n)] == k) #The final sub-task determines if the final sheep is successfully represented
#
#     for i in range(len(num_sheep_l)):
#         nn, kk = n-num_sheep_l[i],k-num_stick_l[i]  #divide-and-conquer
#         if nn <= 0 or kk <= 0:
#             break
#         res |= Roman_shepherds(nn,kk)            #once any sub-task is solved, the whole task is solved!
#
#     return res

# for i in range(len(num_sheep_l)-1):    #Check '4','5','9','10's multiple
#     i+=1
#     n_mod = n%num_sheep_l[i]
#     k_mod = k%num_stick_l[i]
#     n_quo = n/num_sheep_l[i]
#     k_quo = k/num_stick_l[i]
#
#     if n_mod==0 and k_mod==0 and n_quo==k_quo:
#         return True


#optimized version : Memoization
global mem_map
mem_map = {}
def Roman_shepherds(n,k):
    global res
    if n < k: return False

    key = str(n)+'_'+str(k)
    if key in mem_map:                              #Check if (n,k) is calculated yet
        return mem_map[key]

    if n in num_sheep_l:
        res = (sheep_stick_dict[str(n)] == k)       #The final sub-task determines if the final sheep is successfully represented

    if not res:
        for i in range(len(num_sheep_l)):
            nn, kk = n-num_sheep_l[i],k-num_stick_l[i]  #divide-and-conquer
            if nn <= 0 or kk <= 0:
                break

            flg = Roman_shepherds(nn,kk)               #once any sub-task is solved, the whole task is solved!
            # Memoization
            mem_map[str(n)+'_'+str(k)] = flg
            res |= flg

            if res:
                break

    return res

def in_proc():
    try:
        global res
        num = int(raw_input("Plz input a positive integer!"))
        for i in range(num):
            res = False
            params = raw_input("Enter n and k:(e.g., 10 4) then press <enter>:")
            n,k, = params.split()
            n,k, = int(n),int(k)
            out_proc(Roman_shepherds(n,k))
            mem_map = {}
        res = False
        in_proc()
    except ValueError:
        print("Invalid value")
        in_proc()

    return True

def out_proc(flag):
    if flag:
        print("O")
    else:
        print("X")

def main():
    in_proc()

if __name__ == "__main__":
    main()