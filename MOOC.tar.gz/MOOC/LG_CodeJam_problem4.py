

class JumpingSpider:
    def __init__(self):
        self.res = 0
        self.num_segments = 0
        self.segmentList = []
        self.node_value_list = []

    def _input_(self):
        '''
        receive input and save
        :return:
        '''
        self.num_points = map(int,raw_input())
        for i in range(self.num_segments):
            L,M,N = map(int,raw_input().strip().split())
            self.segmentList.append([L,M,N])


    def ifIntersect(self,x1,y1,x2,y2,x3,y3,x4,y4):
        '''
        check if two segments are intersected with each other
        :param x1:
        :param y1:
        :param x2:
        :param y2:
        :return:
        '''

        return  max(x1,x2) >= min(x3,x4) and \
                max(x3,x4) >= min(x1,x2) and \
                max(y1,y2) >= min(y3,y4) and \
                max(y3,y4) >= min(y1,y2)

    def count(self, num_test):
        for _ in range(num_test):
            self.__init__()
            self._input_()

            # node value map to record each node's sum of input and output numbers
            for L in range(self.num_segments*2):
                if L<2:
                    self.node_value_list.append(2)
                elif L>(self.num_segments-1)*2:
                    self.node_value_list.append(2)
                else:
                    self.node_value_list.append(4)



            for p in range(self.num_segments - 2):

                xL1 = self.segmentList[p][0]
                L1y1 = self.segmentList[p][1]
                L1y2 = self.segmentList[p][2]

                xL2 = self.segmentList[p+1][0]
                L2y1 = self.segmentList[p+1][1]
                L2y2 = self.segmentList[p+1][2]

                xL3 = self.segmentList[p+2][0]
                L3y1 = self.segmentList[p+2][1]
                L3y2 = self.segmentList[p+2][2]

                if self.ifIntersect(xL1,L1y1, xL3,L3y1,     xL2,L2y1,xL2,L2y2):
                    self.node_value_list[(p+2)*2] += 1
                if self.ifIntersect(xL1,L1y1, xL3,L3y2,     xL2,L2y1,xL2,L2y2):
                    self.node_value_list[(p+2)*2+1] += 1
                if self.ifIntersect(xL1,L1y2, xL3,L3y1,     xL2,L2y1,xL2,L2y2):
                    self.node_value_list[(p+2)*2] += 1
                if self.ifIntersect(xL1,L1y2, xL3,L3y2,     xL2,L2y1,xL2,L2y2):
                    self.node_value_list[(p+2)*2+1] += 1
























def main():
    num_test = input()
    JumpingSpider().count(num_test)

if __name__ == '__main__':
    main()
