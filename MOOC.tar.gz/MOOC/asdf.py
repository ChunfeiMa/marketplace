#!/bin/python3

import sys

y = int(input().strip())
#your code goes here

DDay = 256
days_of_month = [31,29,31,30,31,30,31,31,30,31,30,31]
accumlatedList = []
sum_ = 0
lastSum = 0
for i in range(len(days_of_month)-1):
    sum_+= days_of_month[i]
    if lastSum <= DDay and DDay <= sum_:
        ret = DDay - lastSum
        break
    lastSum = sum_

if y%4==0:
    ret-=1

print("{0:0=2d}.{1:0=2d}.{2:0=4d}".format(ret+1,i+1,y))


