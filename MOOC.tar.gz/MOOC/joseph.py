# chunfei.ma@lge.com
from __future__ import print_function
global num,interval,group_num,size
list = []
head_node = []
tail_node = []
pointer = []
result = []
size = 2

def circular_push_back(data):
    global num,list,head_node,pointer

    if not head_node:
        head_node = [data, None]
        pointer = head_node
    else:
        pointer[1] = [data, head_node]
        pointer = pointer[1]

# Method 2 (Non-circular linked list)
def circular_erase(n_index):
    global num,list,head_node,pointer,size,result
    result = []
    size = None
    while size != 1:
        pointer = []
        pointer = list
        temp = []

        for i in range(num):
            temp.append(pointer[0])
            pointer = pointer[1]

        if size == None:# kill the first people
            pass
        elif size > n_index:
            temp = temp[n_index-1:] + temp[:n_index-1]
        else:
            temp_index = n_index%size
            temp = temp[temp_index-1:] + temp[:temp_index-1]
        result.append(temp[0])
        del temp[0]

        del pointer
        del head_node
        del list
        pointer = []
        head_node = []
        list = []

        size = len(temp)
        num = size
        for i in range(size):
            circular_push_back(temp[i])

        list = head_node
        circular_show()
        print("Killed:{0}".format(result))
    list = []
    pointer = []
    head_node = []

# Method 1 (circular linked list)
def circular_erase_(n_index):
    global list,num,head_node,pointer,result
    result = []
    pointer = []
    size = num
    count = 0
    while size != 1:
        pointer = list

        for i in range(n_index-1):
            pointer = pointer[1]

        result.append(pointer[1][0])
        # kill this
        pointer[1] = pointer[1][1]
        list = pointer
        size -= 1
        num = size
        pointer = []

        circular_show()
        print("Killed:{0}".format(result))

    list = []
    head_node = []

def circular_show():
    pointer = list
    for i in range(num):
        print("{0}  ".format(pointer[0]),end='')
        pointer = pointer[1]

def in_porc():
    global num,list,head_node,interval,group_num
    while True:
        try:
             params = raw_input("Enter of mans and step, groups:(e.g., 10 4 2) then press <enter>:")
             if len(params)!= 1:
                 num,interval,group_num = params.split()
                 num,interval,group_num = int(num),int(interval),int(group_num)
                 print("num = {0}, interval = {1}, group_num = {2}".format(num,interval,group_num))
                 if num<interval:
                     print("mans cannot less than step! Input again!")
                     continue
             else:
                 print("\n Bye!")
                 break

             data = range(num)
             data = data[-interval:] + data[:num - interval]
             # push back each data
             for i in range(num):
                 circular_push_back(data[i])


             list = head_node
             # displayss
             # circular_show()

             extraction()
             out_proc()

        except ValueError:
             print("Invalid Value!")

def out_proc():
    global result,group_num
    f = open("joseph.dat","wb")
    k = len(result)/group_num

    for i in range(group_num):
        if i<(group_num-1):
            print("Group{0}:{1}".format(i,result[i*k:(i+1)*k]))
            f.write(str(result[i*k:(i+1)*k]))
        else:
            print("Group{0}:{1}".format(i,result[i*k:]))
            f.write(str(result[i*k:]))
    f.close()


def extraction():
    global interval
    # circular_erase(interval)
    circular_erase_(interval)

def main():
    in_porc()
    # circular_show()
    # extraction()
    # out_proc()

if __name__ == "__main__":
    main()