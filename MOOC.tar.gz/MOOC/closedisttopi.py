#!/bin/python3

import sys,math


min,max = input().strip().split(' ')
min,max = [int(min),int(max)]
# your code goes here

pi = math.pi
v = 1000
for i in range(min, max):
    d = i

    a,b = 3.14*d,4*d
    a = int(a)
    b = int(b)
    for j in range(a,b):
        d = float(d)
        n = float(j)
        dist = abs(n/d - pi)
        if dist < v:
            v = dist
            x, y = n, d
print("{0}/{1}".format(int(x),int(y)))
print(x/y)