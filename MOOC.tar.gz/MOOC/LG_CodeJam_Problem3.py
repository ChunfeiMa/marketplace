

class ConnectingPoints:
    def __init__(self):
        self.numofR = 0
        self.numofG = 0
        self.numofP = 0
        self.R = []
        self.G = []
        self.P = []

        self.res = 0

    def _input_(self):
        '''
        receive input and save
        :return:
        '''
        L,M,N = map(int,raw_input().strip().split())
        self.numofR = L
        self.numofG = M
        self.numofP = N

        for l in range(L):
            r = map(int,raw_input())
            self.R.append(r)

        for m in range(M):
            g = map(int,raw_input())
            self.R.append(g)

        for n in range(N):
            p = map(int,raw_input())
            self.R.append(p)

    def count(self, num_test):
        for _ in range(num_test):
            self._input_()
            self.__init__()






















def main():
    num_test = input()
    ConnectingPoints().count(num_test)

if __name__ == '__main__':
    main()
