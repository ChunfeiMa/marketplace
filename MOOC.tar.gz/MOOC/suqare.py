#chunfei.ma@lge.com
from __future__ import print_function
global num,square

def square_odd():
    global  square

    elements = range(1,(num*num)+1)
    length = len(elements)

    square = []
    row = []
    # initial a empty square matrix
    for i in range(num):
        for j in range(num):
            row.append(0)
        square.append(row)
        row = []

    square[0][num/2] = elements[0]
    col_index = num/2
    row_index = 0
    count = 1
    while True:
        row_index -= 1
        col_index -= 1


        if (row_index==-1 and col_index==-1) or (square[row_index][col_index] != 0):
            row_index += 2
            col_index += 1

        elif row_index < 0:
            row_index = num-1

        elif col_index < 0:
            col_index = num-1


        square[row_index][col_index] = elements[count]
        count+=1
        if count==length:
            break

def square_even():
    global  square

    elements = range(1,(num*num)+1)
    length = len(elements)

    square = []
    row = []

    # insert the element one by on
    for i in range(num):
        for j in range(num):
            row.append(elements[i*num + j])
        square.append(row)
        row = []

    square[0][0] = elements[0]

    valid_index_set = ((1,1),(1,4),(2,2),(2,3),(3,2),(3,3),(4,1),(4,4)) # 8 points
    count = 0
    rest_value = []

    for i in range(num):
        for j in range(num):
            if ((i%4)+1,(j%4)+1) not in valid_index_set:
                square[i][j] = 0
                rest_value.append(elements[i*num + j])


    rest_value = rest_value[::-1]
    for i in range(num):
        for j in range(num):
            if square[i][j] == 0:
                square[i][j] = rest_value[count]
                count+=1


def in_proc():
    global  num,_if_end_
    try:
        num = int(raw_input("Plz input a non-zero integer!"))
        if num == 0 or num == 1:
            return False
        if num%2 == 0:
            square_even()
        else:
            square_odd()
    except ValueError:
        print("Invalid value")
        in_proc()

    return True

def out_proc():

    for i in range(num):
        for j in range(num):
            print("{0:6}   ".format(square[i][j]),end='')
        print()




def main():
    print("Main start!")
    while True:
        if in_proc():
            out_proc()
        if num == 0:
            break
    print("Bye!")


if __name__ == "__main__":
    main()
